var searchData=
[
  ['width_653',['width',['../a00959.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::DepthData::width()'],['../a00963.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::DepthImage::width()'],['../a00967.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::DepthIRImage::width()'],['../a01019.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::IntermediateData::width()'],['../a01039.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::IRImage::width()'],['../a01051.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::RawData::width()']]]
];
