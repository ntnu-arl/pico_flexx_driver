var searchData=
[
  ['noise_641',['noise',['../a00955.html#abfc275fb52656acdce57b5d04e251e2d',1,'royale::DepthPoint']]],
  ['numfrequencies_642',['numFrequencies',['../a01019.html#a51fa220d98aa8b5066650d19f922ad2a',1,'royale::IntermediateData']]],
  ['numpoints_643',['numPoints',['../a01055.html#a636d8d20b8eac6749205f21c3c6d45b4',1,'royale::SparsePointCloud']]]
];
