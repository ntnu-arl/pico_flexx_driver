var searchData=
[
  ['globalbinning_5fint_712',['GlobalBinning_Int',['../a00134.html#a939253c294a92fd4eaf824f71f3985caaa3a03ccf5b5263863dd1624a91f70acb',1,'royale']]],
  ['grayimagemeanmap_5fint_713',['GrayImageMeanMap_Int',['../a00134.html#a939253c294a92fd4eaf824f71f3985caaba9b90505abee5c93f2ab420df3e148b',1,'royale']]]
];
