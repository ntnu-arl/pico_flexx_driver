var searchData=
[
  ['i_635',['i',['../a01059.html#acb559820d9ca11295b4500f179ef6392',1,'royale::Variant']]],
  ['illuminationenabled_636',['illuminationEnabled',['../a01051.html#aec6b947da0613a66c1ea5dcc821efc9b',1,'royale::RawData']]],
  ['illuminationtemperature_637',['illuminationTemperature',['../a01051.html#a85c2f86f640d24355db77ee3925ad87a',1,'royale::RawData']]],
  ['intensity_638',['intensity',['../a01015.html#a2dfe87f3417747242e8f043dd4f3fb59',1,'royale::IntermediatePoint']]],
  ['irdata_639',['irData',['../a00967.html#a27a94f2260e0dcd09318c68485478a9c',1,'royale::DepthIRImage']]]
];
