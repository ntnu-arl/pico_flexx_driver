var searchData=
[
  ['modulationfrequencies_640',['modulationFrequencies',['../a01019.html#a8a090127b341725e9898ecf42321e182',1,'royale::IntermediateData::modulationFrequencies()'],['../a01051.html#a8a090127b341725e9898ecf42321e182',1,'royale::RawData::modulationFrequencies()']]]
];
