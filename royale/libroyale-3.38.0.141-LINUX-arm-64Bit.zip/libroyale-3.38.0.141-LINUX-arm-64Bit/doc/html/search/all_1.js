var searchData=
[
  ['b_9',['b',['../a01059.html#a0e1796f93090a23d03395234544109ae',1,'royale::Variant']]],
  ['bool_10',['Bool',['../a00134.html#a8baf1ee0db4eb07d4003875cfe03189cac26f15e86e3de4c398a8273272aba034',1,'royale']]]
];
