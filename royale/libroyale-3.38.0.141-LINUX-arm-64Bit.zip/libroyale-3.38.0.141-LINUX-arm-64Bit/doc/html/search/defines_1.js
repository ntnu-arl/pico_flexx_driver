var searchData=
[
  ['royale_5fapi_800',['ROYALE_API',['../a00035.html#a33c2bff4e946879f1a2d4f6961b6f339',1,'Definitions.hpp']]]
];
