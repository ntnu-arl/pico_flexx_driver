var searchData=
[
  ['rawdata_539',['RawData',['../a01051.html#a9586873066336885be0e4a48a80f40c8',1,'royale::RawData::RawData()'],['../a01051.html#a5279322e511fda362e81ee6bbbf7ac60',1,'royale::RawData::RawData(size_t rawVectorSize)']]],
  ['readregisters_540',['readRegisters',['../a00971.html#a2a67b1dfde68f1ad81300a04a1e2faae',1,'royale::ICameraDevice']]],
  ['registerdatalistener_541',['registerDataListener',['../a00971.html#a8db2c6fe77b49be6a6be238579e2fca9',1,'royale::ICameraDevice']]],
  ['registerdatalistenerextended_542',['registerDataListenerExtended',['../a00971.html#a1257180bf74ce801bc221d54a43c56e5',1,'royale::ICameraDevice']]],
  ['registerdepthimagelistener_543',['registerDepthImageListener',['../a00971.html#a6cc823ebcec871a1f3c9b3b26da9c188',1,'royale::ICameraDevice']]],
  ['registerdepthirimagelistener_544',['registerDepthIRImageListener',['../a00971.html#a7c5ff069ef103188062d2ebb0ec3f4fc',1,'royale::ICameraDevice']]],
  ['registereventlistener_545',['registerEventListener',['../a00951.html#aa3315701cb25383ab438a4f049181b32',1,'royale::CameraManager::registerEventListener()'],['../a00971.html#a43b9868077e54af9c5d458712136f329',1,'royale::ICameraDevice::registerEventListener()'],['../a01027.html#a543af844c74411d945857ce40d72f25b',1,'royale::IRecord::registerEventListener()']]],
  ['registerexposurelistener_546',['registerExposureListener',['../a00971.html#a6d69a6acf024840ee41bdc07846c73de',1,'royale::ICameraDevice::registerExposureListener(royale::IExposureListener *listener)=0'],['../a00971.html#a85c8cd7a2f0957d15152457091305ee9',1,'royale::ICameraDevice::registerExposureListener(royale::IExposureListener2 *listener)=0']]],
  ['registeririmagelistener_547',['registerIRImageListener',['../a00971.html#aa5e4e4fce36a660a450ed8af7b4d73ee',1,'royale::ICameraDevice']]],
  ['registerrecordlistener_548',['registerRecordListener',['../a00971.html#a4546ca824444b8fc9857d126c4dd3d49',1,'royale::ICameraDevice']]],
  ['registersparsepointcloudlistener_549',['registerSparsePointCloudListener',['../a00971.html#a0c6d07004c2f6f1c11222718ef8c6f77',1,'royale::ICameraDevice']]],
  ['registerstoplistener_550',['registerStopListener',['../a01035.html#a377bf5123e81e8acc8691a02c1ead6fd',1,'royale::IReplay']]],
  ['resetparameters_551',['resetParameters',['../a01027.html#a5c8c5368b37e0e1ee668a6b26a32b124',1,'royale::IRecord']]],
  ['resume_552',['resume',['../a01035.html#a6596cf9cc8befb8bce505a0cc4228180',1,'royale::IReplay']]]
];
