var searchData=
[
  ['variant_426',['Variant',['../a01059.html',1,'royale']]]
];
