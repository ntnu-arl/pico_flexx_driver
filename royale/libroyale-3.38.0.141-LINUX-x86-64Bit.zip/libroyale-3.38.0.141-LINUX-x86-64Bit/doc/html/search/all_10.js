var searchData=
[
  ['timeout_333',['TIMEOUT',['../a00134.html#a08d2011020d279958ab43e88aa954f83a070a0fb40f6c308ab544b227660aadff',1,'royale']]],
  ['timestamp_334',['timeStamp',['../a00959.html#ae79bd1a18ab6e0c28084edf8df849fd5',1,'royale::DepthData::timeStamp()'],['../a01019.html#ae79bd1a18ab6e0c28084edf8df849fd5',1,'royale::IntermediateData::timeStamp()'],['../a01051.html#ae79bd1a18ab6e0c28084edf8df849fd5',1,'royale::RawData::timeStamp()'],['../a00963.html#a8a591d341723df9496cda98e225b25b4',1,'royale::DepthImage::timestamp()'],['../a00967.html#a8a591d341723df9496cda98e225b25b4',1,'royale::DepthIRImage::timestamp()'],['../a01039.html#a8a591d341723df9496cda98e225b25b4',1,'royale::IRImage::timestamp()'],['../a01055.html#a8a591d341723df9496cda98e225b25b4',1,'royale::SparsePointCloud::timestamp()']]],
  ['triggermode_335',['TriggerMode',['../a00134.html#aa534ed76b07c3983382a53e00e53e94a',1,'royale']]],
  ['triggermode_2ehpp_336',['TriggerMode.hpp',['../a00026.html',1,'']]],
  ['type_337',['type',['../a00987.html#aa470e5410b98509a9fe7e8da34a923cf',1,'royale::IEvent']]]
];
