var searchData=
[
  ['rawdata_648',['rawData',['../a01051.html#aa9e98afc59eb87b8a984df102ea79f10',1,'royale::RawData']]],
  ['rawframecount_649',['rawFrameCount',['../a01051.html#a1547f2f871c0fd55000faf697af6bd0a',1,'royale::RawData']]]
];
