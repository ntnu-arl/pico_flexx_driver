var searchData=
[
  ['version_652',['version',['../a00959.html#aad880fc4455c253781e8968f2239d56f',1,'royale::DepthData::version()'],['../a01019.html#aad880fc4455c253781e8968f2239d56f',1,'royale::IntermediateData::version()']]]
];
