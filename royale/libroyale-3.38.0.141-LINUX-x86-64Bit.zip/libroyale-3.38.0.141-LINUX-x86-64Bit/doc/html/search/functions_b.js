var searchData=
[
  ['type_583',['type',['../a00987.html#aa470e5410b98509a9fe7e8da34a923cf',1,'royale::IEvent']]]
];
